# remove the files that can be installed
echo Cleaning up the virtual environment
rm -r __pycache__ 2>/dev/null
rm -r vcwk 2>/dev/null
rm .env 2>/dev/null


